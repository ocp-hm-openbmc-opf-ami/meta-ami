#include <libpldm/rde.h>

#include <endian.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "msgbuf.h"

LIBPLDM_ABI_STABLE
int encode_negotiate_redfish_parameters_req(
    uint8_t instance_id, uint8_t concurrency_support,
    bitfield16_t* feature_support, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);
    
    if (msg == NULL || feature_support == NULL || concurrency_support == 0)
    {
        return PLDM_ERROR_INVALID_DATA;
    }
    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_NEGOTIATE_REDFISH_PARAMETERS;
    uint8_t rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(
		buf, RDE_NEGOTIATE_REDFISH_PARAMETERS_REQ_BYTES,
		msg->payload, RDE_NEGOTIATE_REDFISH_PARAMETERS_REQ_BYTES);
	if (rc) {
		return rc;
	}

	pldm_msgbuf_insert(buf, concurrency_support);
	pldm_msgbuf_insert(buf, feature_support->value);

	return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_negotiate_redfish_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    struct pldm_rde_device_info* device,
    struct pldm_rde_varstring** device_provider_name)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || device == NULL || completion_code == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(
		buf, RDE_NEGOTIATE_REDFISH_PARAMETERS_RESP_BYTES,
		msg->payload, payload_length);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_extract_p(buf, completion_code);
	if (*completion_code != PLDM_SUCCESS) {
		return *completion_code;
	}
    pldm_msgbuf_extract(buf, device->device_concurrency);
	pldm_msgbuf_extract(buf, device->device_capabilities_flag.byte);
	pldm_msgbuf_extract(buf, device->device_feature_support.value);
	pldm_msgbuf_extract(buf, device->device_configuration_signature);
	size_t remaining_len;
	pldm_msgbuf_span_remaining(buf, (void **)device_provider_name, &remaining_len);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_negotiate_medium_parameters_req(
    uint8_t instance_id, uint32_t maximum_transfer_size, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }
    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_NEGOTIATE_MEDIUM_PARAMETERS;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(
		buf, RDE_NEGOTIATE_MEDIUM_PARAMETERS_REQ_BYTES,
		msg->payload, RDE_NEGOTIATE_MEDIUM_PARAMETERS_REQ_BYTES);
    if (rc != PLDM_SUCCESS) {
		fprintf(stderr, "init failed\n");
		return rc;
	}

    pldm_msgbuf_insert(buf, maximum_transfer_size);

	return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_negotiate_medium_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint32_t* device_maximum_transfer_bytes)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || device_maximum_transfer_bytes == NULL ||
        completion_code == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(
		buf, RDE_NEGOTIATE_MEDIUM_PARAMETERS_RESP_BYTES,
		msg->payload, payload_length);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_extract_p(buf, completion_code);
	if (*completion_code != PLDM_SUCCESS) {
		return PLDM_SUCCESS;
	}

    pldm_msgbuf_extract_p(buf, device_maximum_transfer_bytes);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_get_schema_dictionary_req(uint8_t instance_id, uint32_t resource_id,
                                     uint8_t schema_class, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_GET_SCHEMA_DICTIONARY;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_GET_SCHEMA_DICTIONARY_REQ_BYTES,
				    msg->payload, RDE_GET_SCHEMA_DICTIONARY_REQ_BYTES);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_insert(buf, resource_id);
	pldm_msgbuf_insert(buf, schema_class);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_get_schema_dictionary_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* dictionary_format, uint32_t* transfer_handle)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || dictionary_format == NULL || completion_code == NULL ||
        transfer_handle == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_GET_SCHEMA_DICTIONARY_RESP_BYTES,
				    msg->payload, payload_length);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_extract_p(buf, completion_code);
	if (*completion_code != PLDM_SUCCESS) {
		return PLDM_SUCCESS;
	}
    pldm_msgbuf_extract_p(buf, dictionary_format);
	pldm_msgbuf_extract_p(buf, transfer_handle);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_get_schema_uri_req(uint8_t instance_id, uint32_t resource_id,
                              uint8_t req_schema_class,
                              uint8_t oem_extension_num, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_GET_SCHEMA_URI;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_GET_SCHEMA_URI_REQ_BYTES,
				    msg->payload,
				    RDE_GET_SCHEMA_URI_REQ_BYTES);
	if (rc != PLDM_SUCCESS) {
		fprintf(stderr, "init failed\n");
		return rc;
	}

    pldm_msgbuf_insert(buf, resource_id);
	pldm_msgbuf_insert(buf, req_schema_class);
	pldm_msgbuf_insert(buf, oem_extension_num);

	return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_get_schema_uri_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* string_fragment_count, struct pldm_rde_varstring** schema_URI)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || string_fragment_count == NULL ||
        completion_code == NULL || schema_URI == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_GET_SCHEMA_URI_RESP_BYTES,
				    msg->payload, payload_length);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_extract_p(buf, completion_code);
	if (*completion_code != PLDM_SUCCESS) {
		fprintf(stderr, "COMPLETION CODE ERROR\n");
        return *completion_code;
	}
    pldm_msgbuf_extract_p(buf, string_fragment_count);
    size_t remaining_len;
    pldm_msgbuf_span_remaining(buf, (void **)schema_URI, &remaining_len);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_get_resource_etag_req(uint8_t instance_id, uint32_t resource_id,
                                 struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_GET_RESOURCE_ETAG;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_GET_RESOURCE_ETAG_REQ_BYTES,
				    msg->payload,
				    RDE_GET_RESOURCE_ETAG_REQ_BYTES);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_insert(buf, resource_id);
    
    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_get_resource_etag_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    struct pldm_rde_varstring** ETag)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf,
				    RDE_GET_RESOURCE_ETAG_RESP_BYTES,
				    msg->payload, payload_length);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_extract_p(buf, completion_code);
    size_t remaining_len;
    pldm_msgbuf_span_remaining(buf, (void **)ETag, &remaining_len);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_operation_init_req(
    uint8_t instance_id, uint32_t resource_id, uint16_t operation_id,
    uint8_t operation_type, bitfield8_t* operation_flags,
    uint32_t send_data_transfer_handle, uint8_t operation_locator_length,
    uint32_t request_payload_length, const uint8_t* operation_locator,
    uint8_t* request_payload, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || operation_flags == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    if (operation_locator_length > 0 && operation_locator == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    if (request_payload_length > 0 && request_payload == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_OPERATION_INIT;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(
		buf, RDE_OPERATION_INIT_REQ_BYTES, msg->payload,
		RDE_OPERATION_INIT_REQ_BYTES +
			operation_locator_length + request_payload_length);
    if (rc != PLDM_SUCCESS) {
		return rc;
    }

	pldm_msgbuf_insert(buf, resource_id);
	pldm_msgbuf_insert(buf, operation_id);
	pldm_msgbuf_insert(buf, operation_type);
	pldm_msgbuf_insert(buf, operation_flags->byte);
	pldm_msgbuf_insert(buf, send_data_transfer_handle);
	pldm_msgbuf_insert(buf, operation_locator_length);
	pldm_msgbuf_insert(buf, request_payload_length);
    if (operation_flags->bits.bit0) {
		rc = pldm_msgbuf_insert_array(buf, operation_locator_length,
			(const uint8_t *)operation_locator,
			operation_locator_length);
		if (rc) {
			return pldm_msgbuf_discard(buf, rc);
		}
	}
    if (operation_flags->bits.bit1) {
		rc = pldm_msgbuf_insert_array(buf, request_payload_length,
			(const uint8_t *)request_payload,
			request_payload_length);
		if (rc) {
			return pldm_msgbuf_discard(buf, rc);
		}
	}

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_rde_operation_init_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* completion_percentage, uint8_t* operation_status,
    uint32_t* completion_time_seconds, uint32_t* result_transfer_handle,
    uint32_t* response_payload_length, bitfield8_t* permission_flags,
    bitfield8_t* operation_execution_flags,
    struct pldm_rde_varstring** resp_etag, uint8_t** response_payload)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf,
				    RDE_OPERATION_INIT_RESP_BYTES,
				    msg->payload, payload_length);
	if (rc != PLDM_SUCCESS) {
		return rc;
	}

    pldm_msgbuf_extract_p(buf, completion_code);
    pldm_msgbuf_extract_p(buf, operation_status);
	pldm_msgbuf_extract_p(buf, completion_percentage);
	pldm_msgbuf_extract_p(buf, completion_time_seconds);
	pldm_msgbuf_extract(buf, operation_execution_flags->byte);
	pldm_msgbuf_extract_p(buf, result_transfer_handle);
	pldm_msgbuf_extract(buf, permission_flags->byte);
	pldm_msgbuf_extract_p(buf, response_payload_length);
    pldm_msgbuf_span_required(buf, sizeof(uint8_t) + sizeof(uint8_t), (void **)resp_etag);
	pldm_msgbuf_span_required(buf, (*resp_etag)->string_length_bytes, NULL);
    if (*operation_status == PLDM_RDE_OPERATION_COMPLETED)
    {
		pldm_msgbuf_span_required(buf, *response_payload_length,
					  (void **)response_payload);
	}

	return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_supply_custom_request_parameters_req(
    uint8_t instance_id, uint32_t resource_id, uint16_t operation_id,
    uint16_t link_expand, uint16_t collection_skip, uint16_t collection_top,
    uint16_t pagination_offset, uint8_t etag_operation, uint8_t etag_count,
    const uint8_t* etags, uint8_t etags_size, uint8_t header_count,
    const uint8_t* header_info, uint8_t header_info_size, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || (etag_count > 0 && etags == NULL) ||
        (header_count > 0 && header_info == NULL))
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf,
                    RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS_REQ_BYTES,
                    msg->payload,
                    RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS_REQ_BYTES +
                        etags_size + header_info_size);
    if (rc)
    {
        return rc;
    }

    pldm_msgbuf_insert(buf, resource_id);
    pldm_msgbuf_insert(buf, operation_id);
    pldm_msgbuf_insert(buf, link_expand);
    pldm_msgbuf_insert(buf, collection_skip);
    pldm_msgbuf_insert(buf, collection_top);
    pldm_msgbuf_insert(buf, pagination_offset);
    pldm_msgbuf_insert(buf, etag_operation);
    pldm_msgbuf_insert(buf, etag_count);

    if (etag_count > 0 && etags_size > 0)
    {
        rc = pldm_msgbuf_insert_array(buf, etags_size, etags, etags_size);
        if (rc)
        {
            return pldm_msgbuf_discard(buf, rc);
        }
    }

    pldm_msgbuf_insert(buf, header_count);
    if (header_count > 0 && header_info_size > 0)
    {
        rc = pldm_msgbuf_insert_array(buf, header_info_size, header_info,
                                      header_info_size);
        if (rc)
        {
            return pldm_msgbuf_discard(buf, rc);
        }
    }

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_supply_custom_request_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* operation_status, uint8_t* completion_percentage,
    uint32_t* completion_time_seconds, bitfield8_t* operation_execution_flags,
    uint32_t* result_transfer_handle, bitfield8_t* permission_flags,
    uint32_t* response_payload_length, struct pldm_rde_varstring** resp_etag,
    uint8_t** response_payload)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf,
                    RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);
    pldm_msgbuf_extract_p(buf, operation_status);
    pldm_msgbuf_extract_p(buf, completion_percentage);
    pldm_msgbuf_extract_p(buf, completion_time_seconds);
    pldm_msgbuf_extract(buf, operation_execution_flags->byte);
    pldm_msgbuf_extract_p(buf, result_transfer_handle);
    pldm_msgbuf_extract(buf, permission_flags->byte);
    pldm_msgbuf_extract_p(buf, response_payload_length);
    pldm_msgbuf_span_required(buf, sizeof(uint8_t) + sizeof(uint8_t), (void **)resp_etag);
    pldm_msgbuf_span_required(buf, (*resp_etag)->string_length_bytes, NULL);
    if (*operation_status == PLDM_RDE_OPERATION_COMPLETED)
    {
        pldm_msgbuf_span_required(buf, *response_payload_length,
                      (void **)response_payload);
    }

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_retrieve_custom_response_parameters_req(
    uint8_t instance_id, uint32_t resource_id, uint16_t operation_id,
    struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS;
    uint8_t rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(
		buf, RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS_REQ_BYTES
        , msg->payload, RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS_REQ_BYTES);
    if (rc != PLDM_SUCCESS) {
		return rc;
    }

    pldm_msgbuf_insert(buf, resource_id);
    pldm_msgbuf_insert(buf, operation_id);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_retrieve_custom_response_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint32_t* defferal_time_frame, uint32_t* new_resource_id,
    uint8_t* response_header_count, RdeHeaderInfo_T** response_header_info)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || completion_code == NULL || defferal_time_frame == NULL ||
        new_resource_id == NULL || response_header_count == NULL ||
        response_header_info == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf,
                    RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);
    if (*completion_code != PLDM_SUCCESS) {
        return PLDM_SUCCESS;
    }
    pldm_msgbuf_extract_p(buf, defferal_time_frame);
    pldm_msgbuf_extract_p(buf, new_resource_id);
    pldm_msgbuf_extract_p(buf, response_header_count);
    size_t remaining_len;
    pldm_msgbuf_span_remaining(buf, (void **)response_header_info, &remaining_len);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_operation_complete_req(uint8_t instance_id, uint32_t resource_id,
                                      uint16_t operation_id,
                                      struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_OPERATION_COMPLETE;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_COMPLETE_REQ_BYTES,
                    msg->payload, RDE_OPERATION_COMPLETE_REQ_BYTES);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_insert(buf, resource_id);
    pldm_msgbuf_insert(buf, operation_id);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_rde_operation_complete_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || completion_code == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_COMPLETE_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_operation_status_req(uint8_t instance_id, uint32_t resource_id,
                                    uint16_t operation_id, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_OPERATION_STATUS;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_STATUS_REQ_BYTES,
                    msg->payload, RDE_OPERATION_STATUS_REQ_BYTES);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_insert(buf, resource_id);
    pldm_msgbuf_insert(buf, operation_id);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_rde_operation_status_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* operation_status, uint8_t* completion_percentage,
    uint32_t* completion_time_seconds, bitfield8_t* operation_execution_flags,
    uint32_t* result_transfer_handle, bitfield8_t* permission_flags,
    uint32_t* response_payload_length, struct pldm_rde_varstring** resp_etag,
    uint8_t** payload)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_STATUS_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);
    pldm_msgbuf_extract_p(buf, operation_status);
    pldm_msgbuf_extract_p(buf, completion_percentage);
    pldm_msgbuf_extract_p(buf, completion_time_seconds);
    pldm_msgbuf_extract(buf, operation_execution_flags->byte);
    pldm_msgbuf_extract_p(buf, result_transfer_handle);
    pldm_msgbuf_extract(buf, permission_flags->byte);
    pldm_msgbuf_extract_p(buf, response_payload_length);
    pldm_msgbuf_span_required(buf, sizeof(uint8_t) + sizeof(uint8_t), (void **)resp_etag);
    pldm_msgbuf_span_required(buf, (*resp_etag)->string_length_bytes, NULL);
    pldm_msgbuf_span_required(buf, *response_payload_length, (void **)payload);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_operation_kill_req(uint8_t instance_id, uint32_t resource_id,
                                  uint16_t operation_id, bitfield8_t kill_flags,
                                  struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_OPERATION_KILL;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_KILL_REQ_BYTES,
                    msg->payload, RDE_OPERATION_KILL_REQ_BYTES);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_insert(buf, resource_id);
    pldm_msgbuf_insert(buf, operation_id);
    pldm_msgbuf_insert(buf, kill_flags.byte);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_rde_operation_kill_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || completion_code == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_KILL_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_operation_enumerate_req(uint8_t instance_id,
                                       struct pldm_msg* msg)
{
    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_OPERATION_ENUMERATE;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    return PLDM_SUCCESS;
}

LIBPLDM_ABI_STABLE
int decode_rde_operation_enumerate_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint16_t* operation_count, RdeOperationInfo_T** operation_info)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || completion_code == NULL || operation_count == NULL ||
        operation_info == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_OPERATION_ENUMERATE_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);
    pldm_msgbuf_extract_p(buf, operation_count);
    size_t remaining_len;
    pldm_msgbuf_span_remaining(buf, (void **)operation_info, &remaining_len);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_multipart_send_req(
    uint8_t instance_id, uint32_t data_transfer_handle, uint16_t operation_id,
    uint8_t transfer_flag, uint32_t next_data_transfer_handle,
    uint32_t data_length_bytes, const uint8_t* payload, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || payload == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_MULTIPART_SEND;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, RDE_MULTIPART_SEND_REQ_BYTES,
                    msg->payload, RDE_MULTIPART_SEND_REQ_BYTES + data_length_bytes);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_insert(buf, data_transfer_handle);
    pldm_msgbuf_insert(buf, operation_id);
    pldm_msgbuf_insert(buf, transfer_flag);
    pldm_msgbuf_insert(buf, next_data_transfer_handle);
    pldm_msgbuf_insert(buf, data_length_bytes);
    rc = pldm_msgbuf_insert_array(buf, data_length_bytes, payload, data_length_bytes);
    if (rc) {
        return pldm_msgbuf_discard(buf, rc);
    }

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_rde_multipart_send_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* transfer_operation)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || completion_code == NULL || transfer_operation == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_MULTIPART_SEND_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);
    if (*completion_code != PLDM_SUCCESS) {
        return PLDM_ERROR;
    }

    pldm_msgbuf_extract_p(buf, transfer_operation);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int encode_rde_multipart_receive_req(
    uint8_t instance_id, uint32_t data_transfer_handle, uint16_t operation_id,
    uint8_t transfer_operation, struct pldm_msg* msg)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    struct pldm_header_info header = {0};
    header.instance = instance_id;
    header.pldm_type = PLDM_RDE;
    header.msg_type = PLDM_REQUEST;
    header.command = PLDM_RDE_MULTIPART_RECEIVE;
    int rc = pack_pldm_header(&header, &(msg->hdr));
    if (rc != PLDM_SUCCESS)
    {
        return rc;
    }

    rc = pldm_msgbuf_init_errno(buf, sizeof(struct pldm_rde_multipart_receive_req),
                    msg->payload, sizeof(struct pldm_rde_multipart_receive_req));
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_insert(buf, data_transfer_handle);
    pldm_msgbuf_insert(buf, operation_id);
    pldm_msgbuf_insert(buf, transfer_operation);

    return pldm_msgbuf_complete(buf);
}

LIBPLDM_ABI_STABLE
int decode_rde_multipart_receive_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* ret_transfer_flag, uint32_t* ret_data_transfer_handle,
    uint32_t* data_length_bytes, uint8_t** payload)
{
    PLDM_MSGBUF_DEFINE_P(buf);

    if (msg == NULL || completion_code == NULL || ret_transfer_flag == NULL ||
        ret_data_transfer_handle == NULL || data_length_bytes == NULL ||
        payload == NULL)
    {
        return PLDM_ERROR_INVALID_DATA;
    }

    int rc = pldm_msgbuf_init_errno(buf, RDE_MULTIPART_RECV_RESP_BYTES,
                    msg->payload, payload_length);
    if (rc != PLDM_SUCCESS) {
        return rc;
    }

    pldm_msgbuf_extract_p(buf, completion_code);
    if (*completion_code != PLDM_SUCCESS) {
        return PLDM_ERROR;
    }

    pldm_msgbuf_extract_p(buf, ret_transfer_flag);
    pldm_msgbuf_extract_p(buf, ret_data_transfer_handle);
    pldm_msgbuf_extract_p(buf, data_length_bytes);
    pldm_msgbuf_span_required(buf, *data_length_bytes, (void **)payload);

    return pldm_msgbuf_complete(buf);
}
