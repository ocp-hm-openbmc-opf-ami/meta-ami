#ifndef PLDM_RDE_H
#define PLDM_RDE_H

#include <libpldm/base.h>
#include <libpldm/pldm_types.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

// Minimum transfer size allowed is 64 bytes.
#define PLDM_RDE_MIN_TRANSFER_SIZE_BYTES 64
#define PLDM_RDE_MC_TRANSFER_SIZE_BYTES 1024
#define RDE_NEGOTIATE_REDFISH_PARAMETERS_REQ_BYTES 3
#define RDE_NEGOTIATE_REDFISH_PARAMETERS_RESP_BYTES 12
#define RDE_NEGOTIATE_MEDIUM_PARAMETERS_REQ_BYTES 4
#define RDE_NEGOTIATE_MEDIUM_PARAMETERS_RESP_BYTES 5
#define RDE_GET_SCHEMA_DICTIONARY_REQ_BYTES 5
#define RDE_GET_SCHEMA_DICTIONARY_RESP_BYTES 6
#define RDE_GET_SCHEMA_URI_REQ_BYTES 6
#define RDE_GET_SCHEMA_URI_RESP_BYTES 2
#define RDE_GET_RESOURCE_ETAG_REQ_BYTES 4
#define RDE_GET_RESOURCE_ETAG_RESP_BYTES 1
#define RDE_OPERATION_INIT_REQ_BYTES 17
#define RDE_OPERATION_INIT_RESP_BYTES 19
#define RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS_REQ_BYTES 17
#define RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS_RESP_BYTES 19
#define RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS_REQ_BYTES 6
#define RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS_RESP_BYTES 10
#define RDE_OPERATION_COMPLETE_REQ_BYTES 6
#define RDE_OPERATION_COMPLETE_RESP_BYTES 1
#define RDE_OPERATION_STATUS_REQ_BYTES 6
#define RDE_OPERATION_STATUS_RESP_BYTES 19
#define RDE_OPERATION_KILL_REQ_BYTES 7
#define RDE_OPERATION_KILL_RESP_BYTES 1
#define RDE_OPERATION_ENUMERATE_REQ_BYTES 0
#define RDE_OPERATION_ENUMERATE_RESP_BYTES 3
#define RDE_MULTIPART_SEND_REQ_BYTES 15
#define RDE_MULTIPART_SEND_RESP_BYTES 2
#define RDE_MULTIPART_RECV_REQ_BYTES 7
#define RDE_MULTIPART_RECV_RESP_BYTES 10
// #define RDE_READ_OPERATION_INIT_MIN_BYTES 13
#define RDE_OPERATION_MAX_KILL_TIMES 10
enum pldm_rde_request_properties
{
    HTTP_METHOD = 0,
    URI = 1,
    IF_MATCH = 2,
    IF_NONE_MATCH = 3,
    REQUEST_BODY = 4,
    REQUEST_BODY_LENGTH = 5,
};

/** @brief RDE Supported Commands
 */
enum pldm_rde_commands
{
    PLDM_NEGOTIATE_REDFISH_PARAMETERS = 0x01,
    PLDM_NEGOTIATE_MEDIUM_PARAMETERS = 0x02,
    PLDM_GET_SCHEMA_DICTIONARY = 0x03,
    PLDM_GET_SCHEMA_URI = 0x04,
    PLDM_GET_RESOURCE_ETAG = 0x05,
    // PLDM_GET_OEM_COUNT = 0x06,
    // PLDM_GET_OEM_NAME = 0x07,
    // PLDM_GET_REGISTRY_COUNT = 0x08,
    // PLDM_GET_REGISTRY_DETAILS = 0x09,
    // PLDM_SELECT_REGISTRY_VERSION = 0x0A,
    // PLDM_GET_MESSAGE_REGISTRY = 0x0B,
    // PLDM_GET_SCHEMA_FILE = 0x0C,
    PLDM_RDE_OPERATION_INIT = 0x10,
    PLDM_RDE_SUPPLY_CUSTOM_REQUEST_PARAMETERS = 0x11,
    PLDM_RDE_RETRIEVE_CUSTOM_RESPONSE_PARAMETERS = 0x12,
    PLDM_RDE_OPERATION_COMPLETE = 0x13,
    PLDM_RDE_OPERATION_STATUS = 0x14,
    PLDM_RDE_OPERATION_KILL = 0x15,
    PLDM_RDE_OPERATION_ENUMERATE = 0x16,
    PLDM_RDE_MULTIPART_SEND = 0x30,
    PLDM_RDE_MULTIPART_RECEIVE = 0x31
};

/** @brief schemaClass PLDM data type
 *
 * 	DSP0218 Table 3 - schemaClass enumeration
 */
enum pldm_rde_schema_type
{
    PLDM_RDE_SCHEMA_MAJOR = 0,
    PLDM_RDE_SCHEMA_EVENT = 1,
    PLDM_RDE_SCHEMA_ANNOTATION = 2,
    PLDM_RDE_SCHEMA_COLLECTION_MEMBER_TYPE = 3,
    PLDM_RDE_SCHEMA_ERROR = 4,
    PLDM_RDE_SCHEMA_REGISTRY = 5,
};

/**
 * @brief PLDM RDE completion code definition.
 *
 * DSP0218_1.2.0 Table 37 - PLDM for Redfish Device Enablement completion codes
 */
enum pldm_rde_completion_codes
{
    PLDM_RDE_ERROR_INVALID_TRANSFER_OPERATION_FLAG = 0x21,
    PLDM_RDE_ERROR_CANNOT_CREATE_OPERATION = 0x81,
    PLDM_RDE_ERROR_NOT_ALLOWED = 0x82,
    PLDM_RDE_ERROR_WRONG_LOCATION_TYPE = 0x83,
    PLDM_RDE_ERROR_OPERATION_ABANDONED = 0x84,
    PLDM_RDE_ERROR_OPERATION_UNKILLABLE = 0x85,
    PLDM_RDE_ERROR_OPERATION_EXISTS = 0x86,
    PLDM_RDE_ERROR_OPERATION_FAILED = 0x87,
    PLDM_RDE_ERROR_UNEXPECTED = 0x88,
    PLDM_RDE_ERROR_UNSUPPORTED = 0x89,
    PLDM_RDE_ERROR_UNRECOGNIZED_CUSTOM_HEADER = 0x90,
    PLDM_RDE_ERROR_ETAG_MATCH = 0x91,
    PLDM_RDE_ERROR_NO_SUCH_RESOURCE = 0x92,
    PLDM_RDE_ETAG_CALCULATION_ONGOING = 0x93,
    PLDM_RDE_ERROR_INSUFFICIENT_STORAGE = 0x94,
};

/**
 * @brief PLDM RDE Transfer flags.
 *
 * DSP0218_1.2.0 Table 71 – RDEMultipartSend command format
 */
enum pldm_rde_transfer_flag
{
    PLDM_RDE_START = 0,
    PLDM_RDE_MIDDLE = 1,
    PLDM_RDE_END = 2,
    PLDM_RDE_START_AND_END = 3,
};

/**
 * @brief PLDM RDE Transfer operation flags.
 *
 * DSP0218_1.2.0 Table 71 – RDEMultipartSend command format
 */
enum pldm_rde_transfer_operation
{
    PLDM_RDE_XFER_FIRST_PART = 0,
    PLDM_RDE_XFER_NEXT_PART = 1,
    PLDM_RDE_XFER_ABORT = 2,
    PLDM_RDE_XFER_COMPLETE = 3,
};

/** @brief PLDM DeviceCapabilitiesFlags
 */
enum pldm_rde_device_capabilities_flags
{
    PLDM_RDE_ATOMIC_RESOURCE_READ = 0x00,
    PLDM_RDE_EXPAND_SUPPORT = 0x01,
    PLDM_RDE_BEJ_1_1_SUPPORT = 0x02,
};

/**
 * @brief OperationType used in RDEOperationInit request data structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
enum pldm_rde_operation_type
{
    PLDM_RDE_OPERATION_HEAD = 0,
    PLDM_RDE_OPERATION_READ = 1,    //  GET
    PLDM_RDE_OPERATION_CREATE = 2,  //  POST
    PLDM_RDE_OPERATION_DELETE = 3,  //  DELETE
    PLDM_RDE_OPERATION_UPDATE = 4,  //  PATCH
    PLDM_RDE_OPERATION_REPLACE = 5, //  PUT
    PLDM_RDE_OPERATION_ACTION = 6,  //  POST
};

/**
 * @brief OperationFlags used in RDEOperationInit request data
 * structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
enum pldm_rde_operation_flags
{
    PLDM_RDE_LOCATOR_VALID = 0x00,
    PLDM_RDE_CONTAINS_REQUEST_PAYLOAD = 0x01,
    PLDM_RDE_CONTAINS_CUSTOM_REQUEST_PARAMETERS = 0x02,
    PLDM_RDE_EXCERPT_FLAG = 0x03,
};

/**
 * @brief OperationStatus used in RDEOperationInit response data structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
enum pldm_rde_operation_status
{
    PLDM_RDE_OPERATION_INACTIVE = 0,
    PLDM_RDE_OPERATION_NEEDS_INPUT = 1,
    PLDM_RDE_OPERATION_TRIGGERED = 2,
    PLDM_RDE_OPERATION_RUNNING = 3,
    PLDM_RDE_OPERATION_HAVE_RESULTS = 4,
    PLDM_RDE_OPERATION_COMPLETED = 5,
    PLDM_RDE_OPERATION_FAILED = 6,
    PLDM_RDE_OPERATION_ABANDONED = 7,
};

/**
 * @brief OperationExecutionFlags used in RDEOperationInit response data
 * structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
enum pldm_rde_operation_excution_flags
{
    PLDM_RDE_TASK_SPAWNED = 0,
    PLDM_RDE_HAVE_CUSTOM_RESPONSE_PARAMETERS = 1,
    PLDM_RDE_HAVE_RESULT_PAYLOAD = 2,
    PLDM_RDE_CACHE_ALLOWED = 3,
};

/**
 * @brief PermissionFlags used in RDEOperationInit response data
 * structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
enum pldm_rde_permission_flags
{
    PLDM_RDE_READ_ALLOWED = 0,
    PLDM_RDE_UPDATE_ALLOWED = 1,
    PLDM_RDE_REPLACE_ALLOWED = 2,
    PLDM_RDE_CREATE_ALLOWED = 3,
    PLDM_RDE_DELETE_ALLOWED = 4,
    PLDM_RDE_HEAD_ALLOWED = 5,
};

/**
 * @brief ETagOperation used in SupplyCustomRequestParameters request data
 * structure.
 *
 * DSP0218_1.2.0 Table 65 - SupplyCustomRequestParameters command format
 */
enum pldm_rde_etag_operation
{
    PLDM_RDE_ETAG_IGNORE = 0,
    PLDM_RDE_ETAG_IF_MATCH = 1,
    PLDM_RDE_ETAG_IF_NONE_MATCH = 2,
};

/**
 * @brief KillFlags used in RDEOperationKill request data structure.
 *
 * DSP0218_1.2.0 Table 69 - RDEOperationKill command format
 */
enum pldm_rde_kill_flags
{
    PLDM_RDE_DISCARD_RECORD = 0,
    PLDM_RDE_RUN_TO_COMPLETION = 1,
    PLDM_RDE_DISCARD_RESULT = 2,
};

/**
 * @brief NegotiateRedfishParameters request data structure.
 */
struct pldm_rde_negotiate_redfish_parameters_req
{
    uint8_t mc_concurrency_support;
    bitfield16_t mc_feature_support;
} __attribute__((packed));

/**
 * @brief varstring PLDM data type.
 *
 * sizeof(struct pldm_rde_varstring) will include the space for the NULL
 * character.
 */
struct pldm_rde_varstring
{
    uint8_t string_format;
    // Includes NULL terminator.
    uint8_t string_length_bytes;
    // String data should be NULL terminated.
    uint8_t string_data[1];
} __attribute__((packed));

enum pldm_rde_varstring_format
{
    PLDM_RDE_VARSTRING_FORMAT_UNKNOWN = 0,
    PLDM_RDE_VARSTRING_FORMAT_ASCII = 1,
    PLDM_RDE_VARSTRING_FORMAT_UTF8 = 2,
    PLDM_RDE_VARSTRING_FORMAT_UTF16 = 3,
    PLDM_RDE_VARSTRING_FORMAT_UTF16LE = 4,
    PLDM_RDE_VARSTRING_FORMAT_UTF16BE = 5,
};

/**
 * @brief NegotiateRedfishParameters response data structure.
 */
struct pldm_rde_negotiate_redfish_parameters_resp
{
    uint8_t completion_code;
    uint8_t device_concurrency_support;
    bitfield8_t device_capabilities_flags;
    bitfield16_t device_feature_support;
    uint32_t device_configuration_signature;
    struct pldm_rde_varstring device_provider_name;
} __attribute__((packed));

/**
 * @brief NegotiateMediumParameters request data structure.
 */
struct pldm_rde_negotiate_medium_parameters_req
{
    uint32_t mc_maximum_transfer_chunk_size_bytes;
} __attribute__((packed));

/**
 * @brief NegotiateMediumParameters response data structure.
 */
struct pldm_rde_negotiate_medium_parameters_resp
{
    uint8_t completion_code;
    uint32_t device_maximum_transfer_chunk_size_bytes;
} __attribute__((packed));

/**
 * @brief GetSchemaDictionary request data structure.
 */
struct pldm_rde_get_schema_dictionary_req
{
    uint32_t resource_id;
    uint8_t requested_schema_class;
} __attribute__((packed));

/**
 * @brief GetSchemaDictionary response data structure.
 */
struct pldm_rde_get_schema_dictionary_resp
{
    uint8_t completion_code;
    uint8_t dictionary_format;
    uint32_t transfer_handle;
} __attribute__((packed));

/**
 * @brief GetSchemaURI request data structure.
 */
struct pldm_rde_get_schema_uri_req
{
    uint32_t resource_id;
    uint8_t requested_schema_class;
    // Shall be zero for a standard DMTF-published schema, or the one-based OEM
    // extension to a standard schema
    uint8_t oem_extension_number;
} __attribute__((packed));

/**
 * @brief GetSchemaURI response data structure.
 */
struct pldm_rde_get_schema_uri_resp
{
    uint8_t completion_code;
    uint8_t string_fragment_count;
    struct pldm_rde_varstring schema_URI[1];
} __attribute__((packed));

/**
 * @brief GetResourceETag request data structure.
 */
struct pldm_rde_get_resource_etag_req
{
    uint32_t resource_id;
} __attribute__((packed));

/**
 * @brief GetResourceETag response data structure.
 */
struct pldm_rde_get_resource_etag_resp
{
    uint8_t completion_code;
    struct pldm_rde_varstring ETag;
} __attribute__((packed));

/**
 * @brief RDEOperationInit request data structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
struct pldm_rde_operation_init_req
{
    uint32_t resource_id;
    uint16_t operation_id;
    uint8_t operation_type;
    bitfield8_t operation_flags;
    uint32_t send_data_transfer_handle;
    uint8_t operation_locator_length;
    uint32_t request_payload_length;
    // Variable length data: bejLocator and the payload.
    uint8_t var_data[1];
} __attribute__((packed));

/**
 * @brief RDEOperationInit response data structure.
 *
 * DSP0218_1.2.0 Table 64 - RDEOperationInit command format
 */
struct pldm_rde_operation_init_resp
{
    uint8_t completion_code;
    uint8_t operation_status;
    uint8_t completion_percentage;
    uint32_t completion_time_seconds;
    bitfield8_t operation_execution_flags;
    uint32_t result_transfer_handle;
    bitfield8_t permission_flags;
    uint32_t response_payload_length;
    struct pldm_rde_varstring ETag;
    uint8_t response_payload[1];
} __attribute__((packed));

/**
 * @brief RdeHeaderInfo_T used in SupplyCustomRequestParameters request data
 * structure.
 *
 * DSP0218_1.2.0 Table 65 – SupplyCustomRequestParameters command format
 */
typedef struct
{
    struct pldm_rde_varstring header_name;
    struct pldm_rde_varstring header_parameter;
} __attribute__((packed)) RdeHeaderInfo_T;

/**
 * @brief SupplyCustomRequestParameters request data structure.
 *
 * DSP0218_1.2.0 Table 65 – SupplyCustomRequestParameters command format
 */
struct pldm_rde_supply_custom_request_parameters_req
{
    uint32_t resource_id;
    uint16_t operation_id;
    uint16_t link_expand;
    uint16_t collection_skip;
    uint16_t collection_top;
    uint16_t pagination_offset;
    uint8_t etag_operation;
    uint8_t etag_count;
    struct pldm_rde_varstring* ETag;
    uint8_t header_count;
    RdeHeaderInfo_T* header_info;
} __attribute__((packed));

/**
 * @brief SupplyCustomRequestParameters response data structure.
 *
 * DSP0218_1.2.0 Table 65 – SupplyCustomRequestParameters command format
 */
struct pldm_rde_supply_custom_request_parameters_resp
{
    uint8_t completion_code;
    uint8_t operation_status;
    uint8_t completion_percentage;
    uint32_t completion_time_seconds;
    bitfield8_t operation_execution_flags;
    uint32_t result_transfer_handle;
    bitfield8_t permission_flags;
    uint32_t response_payload_length;
    struct pldm_rde_varstring ETag;
    uint8_t response_payload[1];
} __attribute__((packed));

/**
 * @brief RetrieveCustomResponseParameters request data structure.
 *
 * DSP0218_1.2.0 Table 66 – RetrieveCustomResponseParameters command format
 */
struct pldm_rde_retrieve_custom_response_parameters_req
{
    uint32_t resource_id;
    uint16_t operation_id;
} __attribute__((packed));

/**
 * @brief RetrieveCustomResponseParameters response data structure.
 *
 * DSP0218_1.2.0 Table 66 – RetrieveCustomResponseParameters command format
 */
struct pldm_rde_retrieve_custom_response_parameters_resp
{
    uint8_t completion_code;
    uint32_t defferal_time_frame;
    uint32_t new_resource_id;
    uint8_t response_header_count;
    RdeHeaderInfo_T* response_header_info;
} __attribute__((packed));

/**
 * @brief RDEOperationComplete request data structure.
 *
 * DSP0218_1.2.0 Table 67 - RDEOperationComplete command format
 */
struct pldm_rde_operation_complete_req
{
    uint32_t resource_id;
    uint16_t operation_id;
} __attribute__((packed));

/**
 * @brief RDEOperationComplete response data structure.
 *
 * DSP0218_1.2.0 Table 67 - RDEOperationComplete command format
 */
struct pldm_rde_operation_complete_resp
{
    uint8_t completion_code;
} __attribute__((packed));

/**
 * @brief RDEOperationStatus request data structure.
 *
 * DSP0218_1.2.0 Table 68 - RDEOperationStatus command format
 */
struct pldm_rde_operation_status_req
{
    uint32_t resource_id;
    uint16_t operation_id;
} __attribute__((packed));

/**
 * @brief RDEOperationStatus response data structure.
 *
 * DSP0218_1.2.0 Table 68 - RDEOperationStatus command format
 */
struct pldm_rde_operation_status_resp
{
    uint8_t completion_code;
    uint8_t operation_status;
    uint8_t completion_percentage;
    uint32_t completion_time_seconds;
    bitfield8_t operation_execution_flags;
    uint32_t result_transfer_handle;
    bitfield8_t permission_flags;
    uint32_t response_payload_length;
    struct pldm_rde_varstring ETag;
    uint8_t response_payload[1];
} __attribute__((packed));

/**
 * @brief RDEOperationKill request data structure.
 *
 * DSP0218_1.2.0 Table 69 - RDEOperationKill command format
 */
struct pldm_rde_operation_kill_req
{
    uint32_t resource_id;
    uint16_t operation_id;
    bitfield8_t kill_flags;
} __attribute__((packed));

/**
 * @brief RDEOperationKill response data structure.
 *
 * DSP0218_1.2.0 Table 69 - RDEOperationKill command format
 */
struct pldm_rde_operation_kill_resp
{
    uint8_t completion_code;
} __attribute__((packed));

/**
 * @brief RdeOperationEnumInfo_T used in RDEOperationEnumerate response command
 * structure
 *
 * DSP0218_1.2.0 Table 70 - RDEOperationEnumerate command format
 */
typedef struct
{
    uint32_t resource_id;
    uint16_t operation_id;
    uint8_t operation_type;
} __attribute__((packed)) RdeOperationInfo_T;

/**
 * @brief RDEOperationEnumerate response data structure.
 *
 * DSP0218_1.2.0 Table 70 - RDEOperationEnumerate command format
 */
struct pldm_rde_operation_enumerate_resp
{
    uint8_t completion_code;
    uint16_t operation_count;
    RdeOperationInfo_T operation_info[1];
} __attribute__((packed));

/**
 * @brief RDEMultipartSend request data structure.
 *
 * DSP0218_1.2.0 Table 71 - RDEMultipartSend command format
 */
struct pldm_rde_multipart_send_req
{
    uint32_t data_transfer_handle;
    uint16_t operation_id;
    uint8_t transfer_flag;
    uint32_t next_data_transfer_handle;
    uint32_t data_length_bytes;
    uint8_t payload[1];
    // uint32_t data_integrity_checksum in last 4 bytes of
    // data if transfer_flag = END or START_AND_END
} __attribute__((packed));

/**
 * @brief RDEMultipartSend response data structure.
 *
 * DSP0218_1.2.0 Table 71 - RDEMultipartSend command format
 */
struct pldm_rde_multipart_send_resp
{
    uint8_t completion_code;
    uint8_t transfer_operation;
} __attribute__((packed));

/**
 * @brief RDEMultipartReceive request data structure.
 *
 * DSP0218_1.2.0 Table 72 - RDEMultipartReceive command format
 */
struct pldm_rde_multipart_receive_req
{
    uint32_t data_transfer_handle;
    uint16_t operation_id;
    uint8_t transfer_operation;
} __attribute__((packed));

/**
 * @brief RDEMultipartReceive response data structure.
 *
 * DSP0218_1.2.0 Table 72 - RDEMultipartReceive command format
 */
struct pldm_rde_multipart_receive_resp
{
    uint8_t completion_code;
    uint8_t transfer_flag;
    uint32_t next_data_transfer_handle;
    uint32_t data_length_bytes;
    uint8_t payload[1];
    // uint32_t data_integrity_checksum in last 4 bytes of
    // data if transfer_flag = END or START_AND_END
} __attribute__((packed));

struct pldm_rde_device_info
{
    uint8_t device_concurrency;
    bitfield8_t device_capabilities_flag;
    bitfield16_t device_feature_support;
    uint32_t device_configuration_signature;
};

/**
 * @brief Encode NegotiateRedfishParameters request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] concurrency_support - MC concurrency support.
 * @param[in] feature_support - MC feature support flags.
 * @param[out] msg - Request message.
 * @return pldm_completion_codes.
 */
int encode_negotiate_redfish_parameters_req(
    uint8_t instance_id, uint8_t concurrency_support,
    bitfield16_t* feature_support, struct pldm_msg* msg);

/**
 * @brief Decode NegotiateRedfishParameters Response.
 *
 * @param[in] msg - Request message.
 * @param[in] payload_length - Length of request message payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] device - Device Info as sent in the response (Memory to be
 * manager by the caller).
 * @param[out] device_provider_name - Device Provider Name
 * @return pldm_completion_codes.
 */
int decode_negotiate_redfish_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    struct pldm_rde_device_info* device,
    struct pldm_rde_varstring** device_provider_name);

/**
 * @brief Encode NegotiateMediumParameters request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] maximum_transfer_size - Maximum amount of data the MC can
 * support for a single message transfer.
 * @param[out] msg - Request message.
 * @return pldm_completion_codes.
 */
int encode_negotiate_medium_parameters_req(
    uint8_t instance_id, uint32_t maximum_transfer_size, struct pldm_msg* msg);

/**
 * @brief Decode Negotiate Medium Parameters response
 *
 * @param[in] msg: PLDM Msg byte array received from the responder
 * @param[in] payload_length: Length of the payload
 * @param[out] completion_code: Completion code as set by the responder
 * @param[out] device_maximum_transfer_bytes: Max bytes device can transfer
 */
int decode_negotiate_medium_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint32_t* device_maximum_transfer_bytes);

/**
 * @brief Encode GetSchemaDictionary request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID of any resource in the Redfish
 * Resource PDR.
 * @param[in] schema_class - The class of schema being requested.
 * @param[out] msg - Request message.
 * @return pldm_completion_codes.
 */
int encode_get_schema_dictionary_req(uint8_t instance_id, uint32_t resource_id,
                                     uint8_t schema_class,
                                     struct pldm_msg* msg);

/**
 * @brief Decode Get Schema Dictionary Response
 *
 * @param[in] msg - Response Message
 * @param[in] payload_length - Length of the payload
 * @param[out] completion_code - Completion Code
 * @param[out] dictionary_format - Dictionary Format for the particular resource
 * id
 * @param[out] transfer_handle - Transfer Handle to be used to get dictionary
 */
int decode_get_schema_dictionary_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* dictionary_format, uint32_t* transfer_handle);

/**
 * @brief Encode Get Schema URI request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID of any resource in the Redfish
 * Resource PDR.
 * @param[in] schema_class - The class of schema being requested.
 * @param[in] oem_extension_num - Shall be zero for a standard DMTF-published
 * schema, or the one-based OEM extension to a standard schema
 * @param[out] msg - Request message.
 * @return pldm_completion_codes.
 */
int encode_get_schema_uri_req(uint8_t instance_id, uint32_t resource_id,
                              uint8_t req_schema_class,
                              uint8_t oem_extension_num, struct pldm_msg* msg);

/**
 * @brief Decode Get Schema URI Response
 *
 * @param[in] msg - Response Message
 * @param[in] payload_length - Length of the payload
 * @param[out] completion_code - Completion Code
 * @param[out] string_fragment_count - The number of fragments N into which the
 * URI string is broken; shall be greater than zero.
 * @param[out] schema_URI - URI string fragment for the schema.
 */
int decode_get_schema_uri_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* string_fragment_count, struct pldm_rde_varstring** schema_URI);

/**
 * @brief Encode Get Resource ETag request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID of any resource in the Redfish
 * Resource PDR.
 * @param[out] msg - Request message.
 * @return pldm_completion_codes.
 */
int encode_get_resource_etag_req(uint8_t instance_id, uint32_t resource_id,
                                 struct pldm_msg* msg);

/**
 * @brief Decode Get Resource ETag Response
 *
 * @param[in] msg - Response Message
 * @param[in] payload_length - Length of the payload
 * @param[out] completion_code - Completion Code
 * @param[out] ETag - The RFC7232-compliant ETag string data
 */
int decode_get_resource_etag_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    struct pldm_rde_varstring** ETag);

/**
 * @brief Encode RDEOperationInit request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID.
 * @param[in] operation_id - Identification number for this operation.
 * @param[in] operation_type - The type of Redfish Operation being
 * performed.
 * @param[in] operation_flags - Flags associated with this Operation.
 * @param[in] send_data_transfer_handle - Handle to be used with the first
 * RDEMultipartSend command.
 * @param[in] operation_locator_length - Length of the OperationLocator for
 * this Operation.
 * @param[in] request_payload_length - Length of the request payload in this
 * message.
 * @param[in] operation_locator - BEJ locator indicating where the new
 * Operation is to take place within the resource.
 * @param[in] request_payload - The request payload.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_operation_init_req(
    uint8_t instance_id, uint32_t resource_id, uint16_t operation_id,
    uint8_t operation_type, bitfield8_t* operation_flags,
    uint32_t send_data_transfer_handle, uint8_t operation_locator_length,
    uint32_t request_payload_length, const uint8_t* operation_locator,
    uint8_t* request_payload, struct pldm_msg* msg);

/**
 * @brief Decode RDEOperationInit response.
 *
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] completion_percentage - Percentage complete.
 * @param[out] operation_status - Status of the operation.
 * @param[out] completion_time_seconds - An estimate of the number of seconds
 * remaining before the Operation is completed.
 * @param[out] result_transfer_handle - A data transfer handle that the MC
 * may use to retrieve a larger response payload.
 * @param[out] response_payload_length - Length of the response payload.
 * @param[out] permission_flags - Indicates the access level granted to the
 * resource targeted by the Operation.
 * @param[out] operation_execution_flags - Explains the result of operation.
 * @param[out] resp_etag - ETag in the response.
 * @param[out] response_payload - The response payload if the payload fits.
 * @return pldm_completion_codes.
 */
int decode_rde_operation_init_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* completion_percentage, uint8_t* operation_status,
    uint32_t* completion_time_seconds, uint32_t* result_transfer_handle,
    uint32_t* response_payload_length, bitfield8_t* permission_flags,
    bitfield8_t* operation_execution_flags,
    struct pldm_rde_varstring** resp_etag, uint8_t** response_payload);

/**
 * @brief Encode SupplyCustomRequestParameters request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID.
 * @param[in] operation_id - Identification number for this operation.
 * @param[in] link_expand - The value of the $expand query parameter.
 * @param[in] collection_skip - The value of the $skip query parameter.
 * @param[in] collection_top - The value of the $top query parameter.
 * @param[in] pagination_offset - The value of the $offset query parameter.
 * @param[in] etag_operation - The ETag operation to be performed.
 * @param[in] etag_count - Number of ETags in the request.
 * @param[in] etags - ETags in the request.
 * @param[in] header_count - Number of custom headers in the request.
 * @param[in] header_info - Custom headers in the request.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_supply_custom_request_parameters_req(
    uint8_t instance_id, uint32_t resource_id, uint16_t operation_id,
    uint16_t link_expand, uint16_t collection_skip, uint16_t collection_top,
    uint16_t pagination_offset, uint8_t etag_operation, uint8_t etag_count,
    const uint8_t* etags, uint8_t etags_size, uint8_t header_count,
    const uint8_t* header_info, uint8_t header_info_size, struct pldm_msg* msg);

/**
 * @brief Decode SupplyCustomRequestParameters response.
 *
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] operation_status - Status of the operation.
 * @param[out] completion_percentage - Percentage complete.
 * @param[out] completion_time_seconds - An estimate of the number of seconds
 * remaining before the Operation is completed.
 * @param[out] operation_execution_flags - Explains the result of operation.
 * @param[out] result_transfer_handle - A data transfer handle that the MC
 * may use to retrieve a larger response payload.
 * @param[out] permission_flags - Indicates the access level granted to the
 * resource targeted by the Operation.
 * @param[out] response_payload_length - Length of the response payload.
 * @param[out] resp_etag - ETag in the response.
 * @param[out] response_payload - The response payload if the payload fits.
 * @return pldm_completion_codes.
 */
int decode_supply_custom_request_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* operation_status, uint8_t* completion_percentage,
    uint32_t* completion_time_seconds, bitfield8_t* operation_execution_flags,
    uint32_t* result_transfer_handle, bitfield8_t* permission_flags,
    uint32_t* response_payload_length, struct pldm_rde_varstring** resp_etag,
    uint8_t** response_payload);

/**
 * @brief Encode RetrieveCustomResponseParameters request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID.
 * @param[in] operation_id - Identification number for this operation.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_retrieve_custom_response_parameters_req(
    uint8_t instance_id, uint32_t resource_id, uint16_t operation_id,
    struct pldm_msg* msg);

/**
 * @brief Decode RetrieveCustomResponseParameters response.
 *
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] defferal_time_frame - The time frame in seconds after which the
 * requester should retry the request.
 * @param[out] new_resource_id - The ResourceID of the resource that is being
 * created or updated.
 * @param[out] response_header_count - Number of custom headers in the response.
 * @param[out] response_header_info - Custom headers in the response.
 * @return pldm_completion_codes.
 */
int decode_retrieve_custom_response_parameters_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint32_t* defferal_time_frame, uint32_t* new_resource_id,
    uint8_t* response_header_count, RdeHeaderInfo_T** response_header_info);

/**
 * @brief Encode RDEOperationComplete request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID.
 * @param[in] operation_id - Identification number for this operation.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_operation_complete_req(uint8_t instance_id, uint32_t resource_id,
                                      uint16_t operation_id,
                                      struct pldm_msg* msg);

/**
 * @brief Decode RDEOperationComplete response.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] completion_code - PLDM completion code.
 * @param[out] msg - Response message will be written to this.
 * @return pldm_completion_codes.
 */
int decode_rde_operation_complete_resp(const struct pldm_msg* msg,
                                       size_t payload_length,
                                       uint8_t* completion_code);

/**
 * @brief Encode RDEOperationStatus request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID.
 * @param[in] operation_id - Identification number for this operation.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_operation_status_req(uint8_t instance_id, uint32_t resource_id,
                                    uint16_t operation_id,
                                    struct pldm_msg* msg);

/**
 * @brief Decode RDEOperationStatus response.
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] operation_status - Status of the operation.
 * @param[out] completion_percentage - Percentage complete.
 * @param[out] completion_time_seconds - An estimate of the number of seconds
 * @param[out] operation_execution_flags - Explains the result of operation.
 * @param[out] result_transfer_handle - A data transfer handle that the MC
 * may use to retrieve a larger response payload.
 * @param[out] permission_flags - Indicates the access level granted to the
 * resource targeted by the Operation.
 * @param[out] response_payload_length - Length of the response payload.
 * @param[out] resp_etag - ETag in the response.
 * @param[out] payload - The response payload if the payload fits.
 * @return pldm_completion_codes.
 */
int decode_rde_operation_status_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* operation_status, uint8_t* completion_percentage,
    uint32_t* completion_time_seconds, bitfield8_t* operation_execution_flags,
    uint32_t* result_transfer_handle, bitfield8_t* permission_flags,
    uint32_t* response_payload_length, struct pldm_rde_varstring** resp_etag,
    uint8_t** payload);

/**
 * @brief Encode RDEOperationKill request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] resource_id - The ResourceID.
 * @param[in] operation_id - Identification number for this operation.
 * @param[in] kill_flags - Flags indicating how the operation should
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_operation_kill_req(uint8_t instance_id, uint32_t resource_id,
                                  uint16_t operation_id, bitfield8_t kill_flags,
                                  struct pldm_msg* msg);

/**
 * @brief Decode RDEOperationKill response.
 *
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @return pldm_completion_codes.
 */
int decode_rde_operation_kill_resp(const struct pldm_msg* msg,
                                   size_t payload_length,
                                   uint8_t* completion_code);

/**
 * @brief Encode RDEOperationEnumerate request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_operation_enumerate_req(uint8_t instance_id,
                                       struct pldm_msg* msg);

/**
 * @brief Decode RDEOperationEnumerate response.
 *
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] operation_count - Number of operations in the response.
 * @param[out] operation_info - Array of operation info structures.
 * @return pldm_completion_codes.
 */
int decode_rde_operation_enumerate_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint16_t* operation_count, RdeOperationInfo_T** operation_info);

/**
 * @brief Encode RDEMultipartSend request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] data_transfer_handle - A handle to uniquely identify the chunk
 * of data to be sent.
 * @param[in] operation_id - Identification number for this operation.
 * @param[in] transfer_flag - The transfer flag indicating the type of transfer
 * being performed.
 * @param[in] next_data_transfer_handle - Handle to be used with the next
 * RDEMultipartSend command.
 * @param[in] data_length_bytes - Length of the payload in bytes.
 * @param[in] payload - The payload to be sent.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_multipart_send_req(
    uint8_t instance_id, uint32_t data_transfer_handle, uint16_t operation_id,
    uint8_t transfer_flag, uint32_t next_data_transfer_handle,
    uint32_t data_length_bytes, const uint8_t* payload, struct pldm_msg* msg);

/**
 * @brief Decode RDEMultipartSend response.
 *
 * @param[in] msg - Response message.
 * @param[in] payload_length - Length of the response payload.
 * @param[out] completion_code - Completion code as set by the responder.
 * @param[out] transfer_operation - The transfer operation returned by RDE.
 * @return pldm_completion_codes.
 */
int decode_rde_multipart_send_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* transfer_operation);

/**
 * @brief Encode RDEMultipartReceive request.
 *
 * @param[in] instance_id - Message's instance id.
 * @param[in] data_transfer_handle - A handle to uniquely identify the chunk
 * of data to be retrieved.
 * @param[in] operation_id - Identification number for this operation.
 * @param[in] transfer_operation - The portion of data requested for the
 * transfer.
 * @param[out] msg - Request will be written to this.
 * @return pldm_completion_codes.
 */
int encode_rde_multipart_receive_req(
    uint8_t instance_id, uint32_t data_transfer_handle, uint16_t operation_id,
    uint8_t transfer_operation, struct pldm_msg* msg);

/**
 * @brief Decode RDE Multipart Receive Response
 *
 * @param[in] msg - Response message
 * @param[in] payload_length - Expected length of the response, since the
 * response could be equal to the negotiated transfer chunk size, the requester
 * should usually set it to the negotiated transfer size
 * @param[out] completion_code - Completion code of the response set by RDE
 * @param[out] ret_transfer_flag - Transfer flag returned by RDE
 * @param[out] ret_transfer_operation - Transfer operation returned by RDE
 * @param[out] data_length_bytes - The length of the payload in response
 * @param[out] payload - Pointer to the payload
 */
int decode_rde_multipart_receive_resp(
    const struct pldm_msg* msg, size_t payload_length, uint8_t* completion_code,
    uint8_t* ret_transfer_flag, uint32_t* ret_data_transfer_handle,
    uint32_t* data_length_bytes, uint8_t** payload);

#ifdef __cplusplus
}
#endif

#endif /* PLDM_RDE_H */
